# Initialize the routes package
from .sentiment import router
